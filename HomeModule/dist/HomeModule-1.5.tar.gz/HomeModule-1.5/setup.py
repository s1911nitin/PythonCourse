from setuptools import setup, find_packages

setup(
    name="HomeModule",
    version=1.5,
    author="Naveen Manali",
    description="Find out average of two numbers",
    packages=["HomeModule"],
    requires=[]
)