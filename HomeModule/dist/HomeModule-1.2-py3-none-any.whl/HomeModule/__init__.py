
try:
    def average(x,y):
        c = (x+y)/2
        return(c)
    x = int(input("Enter the first number: \n"))
    y = int(input("Enter the second number: \n"))
    if __name__=="__main__":
        print("Average:",average(x,y))
except Exception as e:
    print(e)